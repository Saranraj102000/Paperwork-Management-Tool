<style>
    /* Container for the history section */
.history-container {
    padding: 20px;
    background-color: #f9f9f9;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}

/* Header for history section */
.history-container h2 {
    margin-bottom: 20px;
    font-size: 24px;
    color: #333;
}

/* List of history items */
.history-list {
    display: flex;
    flex-direction: column;
    gap: 10px;
}

/* Card for each history item */
.history-card {
    background-color: #fff;
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    padding: 15px;
    display: flex;
    flex-direction: column;
}

/* Header of each history card */
.history-header {
    display: flex;
    justify-content: space-between;
    border-bottom: 1px solid #ddd;
    padding-bottom: 10px;
    margin-bottom: 10px;
}

/* Modified by and date in header */
.history-modified-by {
    font-weight: bold;
    color: #007bff;
}

.history-modified-date {
    color: #888;
}

/* Body of each history card */
.history-body {
    line-height: 1.6;
}

.history-body p {
    margin-bottom: 10px;
}

.history-body pre {
    background-color: #f1f1f1;
    border: 1px solid #ddd;
    border-radius: 4px;
    padding: 10px;
    overflow-x: auto;
    white-space: pre-wrap; /* Ensure long lines break correctly */
}
</style>

<?php
// fetch_history.php

// Database connection
$conn = new mysqli('localhost', 'root', '', 'formdata');

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$id = $_GET['id'];

// Query to get history details including old_value and new_value
$sql = "SELECT * FROM record_history WHERE record_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param('i', $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    echo '<div class="history-container">';
    echo '<h2>Modification History</h2>';
    echo '<div class="history-list>';
    
    while ($row = $result->fetch_assoc()) {
        echo '<div class="history-card">';
        echo '<div class="history-header">';
        echo '<span class="history-modified-by">' . htmlspecialchars($row['modified_by']) . '</span>';
        echo '<span class="history-modified-date">' . htmlspecialchars($row['modified_date']) . '</span>';
        echo '</div>';
        echo '<div class="history-body">';
        echo '<p><strong>Fields Modified:</strong></p>';
        echo '<pre>' . htmlspecialchars($row['modification_details']) . '</pre>'; // Use <pre> for better formatting

        // Display old and new values
        if (!empty($row['old_value']) || !empty($row['new_value'])) {
            echo '<p><strong>Old Value:</strong> ' . htmlspecialchars($row['old_value']) . '</p>';
            echo '<p><strong>New Value:</strong> ' . htmlspecialchars($row['new_value']) . '</p>';
        }

        echo '</div>';
        echo '</div>';
    }
    
    echo '</div>';
    echo '</div>';
} else {
    echo '<p>No history available.</p>';
}

$stmt->close();
$conn->close();
?>

