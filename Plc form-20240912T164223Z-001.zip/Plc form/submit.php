<?php
session_start();


require 'vendor/autoload.php';  // Include Composer's autoloader
require 'phpmailer/src/Exception.php';
require 'phpmailer/src/PHPMailer.php';
require 'phpmailer/src/SMTP.php';

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Border;
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;



$servername = "localhost";
$username = "root";
$password = "";  // replace with your database password
$dbname = "formdata";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


// Function to handle file upload
function uploadFile($fileKey, $uploadDir = "uploads/") {
    if (isset($_FILES[$fileKey]) && $_FILES[$fileKey]['error'] == 0) {
        $filename = $_FILES[$fileKey]['name'];
        $filesize = $_FILES[$fileKey]['size'];

        // Allow all file formats

        if (!file_exists($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }
        $filepath = $uploadDir . basename($filename);
        if (move_uploaded_file($_FILES[$fileKey]["tmp_name"], $filepath)) {
            return $filepath;
        } else {
            return "Error: There was a problem uploading your file.";
        }
    } else {
        return null;  // No file uploaded
    }
}

$resumePath = uploadFile('resume');
$photoIdPath = uploadFile('photo_id');
$waDocumentPath = uploadFile('wa_document');

$recmail = $_SESSION['email']; // Auto-capture "Submitted By" from session

if ($_SERVER["REQUEST_METHOD"] == "POST") {
$email = $_POST['email'];

}


// Prepare and bind
$stmt = $conn->prepare("INSERT INTO paperworkdetails (
    cfirstname, clastname, ceipalid, clinkedinurl, cdob, cmobilenumber, cemail, clocation, chomeaddress, cssn, 
    cwork_authorization_status, cv_validate_status, ccertifications, coverall_experience, crecent_job_title, ccandidate_source, 
    cresume_attached, cphoto_id_attached, cwa_attached, cany_other_specify, employer_own_corporation, employer_corporation_name, 
    fed_id_number, contact_person_name, contact_person_designation, contact_person_address, contact_person_phone_number, 
    contact_person_extension_number, contact_person_email_id, benchsale_recruiter_name, benchsale_recruiter_phone_number, 
    benchsale_recruiter_extension_number, benchsale_recruiter_email_id, website_link, employer_linkedin_url, employer_type, 
    employer_corporation_name1, fed_id_number1, contact_person_name1, contact_person_designation1, contact_person_address1, 
    contact_person_phone_number1, contact_person_extension_number1, contact_person_email_id1, collaboration_collaborate, 
    delivery_manager, delivery_account_lead, team_lead, associate_team_lead, business_unit, client_account_lead, 
    associate_director_delivery, delivery_manager1, delivery_account_lead1, team_lead1, associate_team_lead1, recruiter_name, 
    recruiter_employee_id, pt_support, pt_ownership, coe_non_coe, geo, entity, client, client_manager, client_manager_email_id, 
    end_client, business_track, industry, experience_in_expertise_role, job_code, job_title, primary_skill, secondary_skill, 
    term, duration, project_location, start_date, end_date, payrate, clientrate, margin, vendor_fee, margin_deviation_approval, 
    margin_deviation_reason, ratecard_adherence, ratecard_deviation_reason, ratecard_deviation_approved, payment_term, 
    payment_term_approval, payment_term_deviation_reason, type, submittedby) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

$stmt->bind_param("sssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss", 
    $_POST['cfirst_name'], $_POST['clast_name'], $_POST['ceipal_id'], $_POST['clinkedin_url'], $_POST['cdob'], $_POST['cmobilenumber'], 
    $_POST['cemail'], $_POST['clocation'], $_POST['chomeaddress'], $_POST['cssn'], $_POST['cwork_authorization_status'], 
    $_POST['cv_validate_status'], $_POST['ccertifications'], $_POST['coverall_experience'], $_POST['crecent_job_title'], 
    $_POST['ccandidate_source'], $_POST['cresume_attached'], $_POST['cphoto_id_attached'], $_POST['cwa_attached'], 
    $_POST['cany_other_specify'], $_POST['cemployer_own_corporation'], $_POST['employer_corporation_name'], $_POST['fed_id_number'], 
    $_POST['contact_person_name'], $_POST['contact_person_designation'], $_POST['contact_person_address'], $_POST['contact_person_phone_number'], 
    $_POST['contact_person_extension_number'], $_POST['contact_person_email_id'], $_POST['benchsale_recruiter_name'], 
    $_POST['benchsale_recruiter_phone_number'], $_POST['benchsale_recruiter_extension_number'], $_POST['benchsale_recruiter_email_id'], 
    $_POST['website_link'], $_POST['employer_linkedin_url'], $_POST['employer_type'], $_POST['employer_corporation_name1'], 
    $_POST['fed_id_number1'], $_POST['contact_person_name1'], $_POST['contact_person_designation1'], $_POST['contact_person_address1'], 
    $_POST['contact_person_phone_number1'], $_POST['contact_person_extension_number1'], $_POST['contact_person_email_id1'],$_POST['collaboration_collaborate'], $_POST['delivery_manager'], $_POST['delivery_account_lead'], $_POST['team_lead'], 
    $_POST['associate_team_lead'], $_POST['business_unit'], $_POST['client_account_lead'], $_POST['associate_director_delivery'], 
    $_POST['delivery_manager1'], $_POST['delivery_account_lead1'], $_POST['team_lead1'], $_POST['associate_team_lead1'], 
    $_POST['recruiter_name'], $_POST['recruiter_employee_id'], $_POST['pt_support'], $_POST['pt_ownership'], $_POST['coe_non_coe'], $_POST['geo'], $_POST['entity'], $_POST['client'], $_POST['client_manager'], $_POST['client_manager_email_id'], $_POST['end_client'], 
    $_POST['business_track'], $_POST['industry'], $_POST['experience_in_expertise_role'], $_POST['job_code'], $_POST['job_title'], 
    $_POST['primary_skill'], $_POST['secondary_skill'], $_POST['term'], $_POST['duration'], $_POST['project_location'], $_POST['start_date'], 
    $_POST['end_date'], $_POST['payrate'], $_POST['clientrate'], $_POST['margin'], $_POST['vendor_fee'], $_POST['margin_deviation_approval'], 
    $_POST['margin_deviation_reason'], $_POST['ratecard_adherence'], $_POST['ratecard_deviation_reason'], $_POST['ratecard_deviation_approved'], 
    $_POST['payment_term'], $_POST['payment_term_approval'], $_POST['payment_term_deviation_reason'], $_POST['type'], $recmail);

    // if ($stmt->execute()) {
    // echo "<script>alert('Feedback submitted successfully, and admin notified.'); window.location.href = 'home.php';</script>";
    // }
    if ($stmt->execute()) {
        // Fetch data from database
        $result = $conn->query("SELECT * FROM paperworkdetails WHERE id = LAST_INSERT_ID()");
    
        if ($result && $row = $result->fetch_assoc()) {
            // Create a new Spreadsheet object
            $spreadsheet = new Spreadsheet();
            $sheet = $spreadsheet->getActiveSheet();
    
            // Set headings
            $sheet->mergeCells('A1:B1'); // Merge A1 and B1 for the heading
            $sheet->setCellValue('A1', 'CONSULTANT DETAILS');
            $sheet->getStyle('A1')->getFont()->setBold(true);
            $sheet->getStyle('A1')->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
            $sheet->getStyle('A1')->getFill()->setFillType(Fill::FILL_SOLID)->getStartColor()->setARGB('FFFF00'); // Yellow background
            $sheet->getStyle('A1')->getBorders()->getAllBorders()->setBorderStyle(Border::BORDER_MEDIUM); // Thick borders for heading
    
            // Field name mapping for more user-friendly labels
            $fieldMapping = [
                'cfirstname' => 'Candidate First Name',
                'clastname' => 'Candidate Last Name',
                'ceipalid' => 'CEIPAL Applicant ID',
                'clinkedinurl' => 'Candidate Linkedin URL',
                'cdob' => 'Date of Birth (DD-MMM)',
                'cmobilenumber' => 'Phone Number',
                'cemail' => 'Email ID',
                'clocation' => 'Location (City, State)',
                'chomeaddress' => 'Home Address',
                'cssn' => 'SSN Number (Last 4 Digits Only) / SIN Number / Cedula ID',
                'cwork_authorization_status' => 'Work Authorization Status',
                'cv_validate_status' => 'V-Validated Status(Applicable only for H1B)',
                'ccertifications' => 'Certifications (If Yes please enter the proper certification details)',
                'coverall_experience' => 'Overall Experience',
                'crecent_job_title' => 'Recent Job Title / Role (Current role)',
                'ccandidate_source' => 'Candidate Source',
                'cresume_attached' => 'Resume Attached (Yes / No)',
                'cphoto_id_attached' => 'Photo ID Attached (Yes/No)',
                'cwa_attached' => 'WA Attached (Yes/No)',
                'cany_other_specify' => 'Any Other Specify',
                'employer_own_corporation' => 'Own Corporation',
                'employer_corporation_name' => 'Employer Corporation Name',
                'fed_id_number' => 'FED ID Number / Tax Number',
                'contact_person_name' => 'Contact Person Name (Signing Authority)',
                'contact_person_designation' => 'Contact Person Designation',
                'contact_person_address' => 'Contact person Address',
                'contact_person_phone_number' => 'Contact Person Phone Number',
                'contact_person_extension_number' => 'Contact Person Extn.Number',
                'contact_person_email_id' => 'Contact Person  Email ID',
                'benchsale_recruiter_name' => 'Bench Sale Recruiter Name',
                'benchsale_recruiter_phone_number' => 'Bench Sale Recruiter Phone Number',
                'benchsale_recruiter_extension_number' => 'Bench Sale Recruiter Extn Number',
                'benchsale_recruiter_email_id' => 'Bench Sale Recruiter Email Id',
                'website_link' => 'Web Site',
                'employer_linkedin_url' => 'Employer LinkedIn URL',
                'employer_type' => 'Employer Type',
                'employer_corporation_name1' => 'Employer Corporation Name',
                'fed_id_number1' => 'FED ID Number / Tax Number',
                'contact_person_name1' => 'Contact Person Name (Signing Authority)',
                'contact_person_designation1' => 'Contact Person Designation',
                'contact_person_address1' => 'Contact Person Address',
                'contact_person_phone_number1' => 'Contact Person Phone Number',
                'contact_person_extension_number1' => 'Contact Person Extn.Number',
                'contact_person_email_id1' => 'Contact Person  Email ID',
                'collaboration_collaborate' => 'Collaborate',
                'delivery_manager' => 'Delivery Manager - Collaboration',
                'delivery_account_lead' => 'Delivery Account Lead - Collaboration',
                'team_lead' => 'Team Lead - Collaboration',
                'associate_team_lead' => 'Lead Recruiter - Collaboration',
                'business_unit' => 'Business Unit',
                'client_account_lead' => 'Business Unit',
                'associate_director_delivery' => 'Associate Director Delivery',
                'delivery_manager1' => 'Delivery Manager',
                'delivery_account_lead1' => 'Delivery Account Lead',
                'team_lead1' => 'Team Lead',
                'associate_team_lead1' => 'Lead Recruiter',
                'recruiter_name' => 'Recruiter Name (As per HR Record)',
                'recruiter_employee_id' => 'Recruiter Emp ID',
                'pt_support' => 'PT Support',
                'pt_ownership' => 'PT Ownership',
                'coe_non_coe' => 'Any Other (Specify Like COE/Non-COE)',
                'geo' => 'GEO',
                'entity' => 'Entity',
                'client' => 'Client',
                'client_manager' => 'Client Manager',
                'client_manager_email_id' => 'Client Manager Email ID',
                'end_client' => 'End Client',
                'business_track' => 'Business Track',
                'industry' => 'Industry',
                'experience_in_expertise_role' => 'Experience in Expertise role|Hands on',
                'job_code' => 'Job Code',
                'job_title' => 'Job Title / Role',
                'primary_skill' => 'Primary Skill (Candidate)',
                'secondary_skill' => 'Secondary Skill (Candidate)',
                'term' => 'Term',
                'duration' => 'Duration',
                'project_location' => 'Project Location',
                'start_date' => 'Start Date (DD-MMM-YYYY)',
                'end_date' => 'End Date (DD-MMM-YYYY) / Tentative',
                'payrate' => 'Pay Rate / Salary',
                'clientrate' => 'Client Rate / Salary',
                'margin' => 'Margin',
                'vendor_fee' => 'Additional Vendor Fee (If applicable)',
                'margin_deviation_approval' => 'Margin Deviation Approval (Yes/No)',
                'margin_deviation_reason' => 'Margin Deviation Reason',
                'ratecard_adherence' => 'Rate Card Adherence(Yes/No)',
                'ratecard_deviation_reason' => 'Rate Card Deviation Reason',
                'ratecard_deviation_approved' => 'Rate Card Deviation Approved (Yes/No)',
                'payment_term' => 'Payment Term',
                'payment_term_approval' => 'Payment Term Approval (Yes/No)',
                'payment_term_deviation_reason' => 'Payment Term Deviation Reason',
                'type' => 'Type'
            ];
    
            $rowIndex = 2;
            foreach ($row as $key => $value) {
                if ($key == 'cany_other_specify') {
                    $rowIndex += 2;
                    $sheet->mergeCells('A' . $rowIndex . ':B' . $rowIndex); // Merge for heading
                    $sheet->setCellValue('A' . $rowIndex, 'EMPLOYER DETAILS');
                    $sheet->getStyle('A' . $rowIndex)->getFont()->setBold(true);
                    $sheet->getStyle('A' . $rowIndex)->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
                    $sheet->getStyle('A' . $rowIndex)->getFill()->setFillType(Fill::FILL_SOLID)->getStartColor()->setARGB('FFFF00'); // Yellow background
                    $sheet->getStyle('A' . $rowIndex)->getBorders()->getAllBorders()->setBorderStyle(Border::BORDER_THIN); // Thick borders for heading
                    $rowIndex++;
                }
                if ($key == 'employer_linkedin_url') {
                    $rowIndex += 2;
                    $sheet->mergeCells('A' . $rowIndex . ':B' . $rowIndex); // Merge for heading
                    $sheet->setCellValue('A' . $rowIndex, 'ADDITIONAL EMPLOYER DETAILS');
                    $sheet->getStyle('A' . $rowIndex)->getFont()->setBold(true);
                    $sheet->getStyle('A' . $rowIndex)->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
                    $sheet->getStyle('A' . $rowIndex)->getFill()->setFillType(Fill::FILL_SOLID)->getStartColor()->setARGB('FFFF00'); // Yellow background
                    $sheet->getStyle('A' . $rowIndex)->getBorders()->getAllBorders()->setBorderStyle(Border::BORDER_THIN); // Thick borders for heading
                    $rowIndex++;
                }
                if ($key == 'contact_person_email_id1') {
                    $rowIndex += 2;
                    $sheet->mergeCells('A' . $rowIndex . ':B' . $rowIndex); // Merge for heading
                    $sheet->setCellValue('A' . $rowIndex, 'COLLABORATION DETAILS');
                    $sheet->getStyle('A' . $rowIndex)->getFont()->setBold(true);
                    $sheet->getStyle('A' . $rowIndex)->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
                    $sheet->getStyle('A' . $rowIndex)->getFill()->setFillType(Fill::FILL_SOLID)->getStartColor()->setARGB('FFFF00'); // Yellow background
                    $sheet->getStyle('A' . $rowIndex)->getBorders()->getAllBorders()->setBorderStyle(Border::BORDER_THIN); // Thick borders for heading
                    $rowIndex++;
                }
                if ($key == 'associate_team_lead') {
                    $rowIndex += 2;
                    $sheet->mergeCells('A' . $rowIndex . ':B' . $rowIndex); // Merge for heading
                    $sheet->setCellValue('A' . $rowIndex, 'RECRUITER DETAILS');
                    $sheet->getStyle('A' . $rowIndex)->getFont()->setBold(true);
                    $sheet->getStyle('A' . $rowIndex)->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
                    $sheet->getStyle('A' . $rowIndex)->getFill()->setFillType(Fill::FILL_SOLID)->getStartColor()->setARGB('FFFF00'); // Yellow background
                    $sheet->getStyle('A' . $rowIndex)->getBorders()->getAllBorders()->setBorderStyle(Border::BORDER_THIN); // Thick borders for heading
                    $rowIndex++;
                }
                if ($key == 'coe_non_coe') {
                    $rowIndex += 2;
                    $sheet->mergeCells('A' . $rowIndex . ':B' . $rowIndex); // Merge for heading
                    $sheet->setCellValue('A' . $rowIndex, 'PROJECT DETAILS');
                    $sheet->getStyle('A' . $rowIndex)->getFont()->setBold(true);
                    $sheet->getStyle('A' . $rowIndex)->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
                    $sheet->getStyle('A' . $rowIndex)->getFill()->setFillType(Fill::FILL_SOLID)->getStartColor()->setARGB('FFFF00'); // Yellow background
                    $sheet->getStyle('A' . $rowIndex)->getBorders()->getAllBorders()->setBorderStyle(Border::BORDER_THIN); // Thick borders for heading
                    $rowIndex++;
                }
    
                // Use the friendly label from the mapping if it exists, otherwise use the original key
                $label = isset($fieldMapping[$key]) ? $fieldMapping[$key] : $key;
    
                $sheet->setCellValue('A' . $rowIndex, $label);
                $sheet->setCellValue('B' . $rowIndex, $value);
                $sheet->getStyle('A' . $rowIndex . ':B' . $rowIndex)->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
                $sheet->getStyle('A' . $rowIndex . ':B' . $rowIndex)->getBorders()->getAllBorders()->setBorderStyle(Border::BORDER_THIN); // Thick borders for data
                $rowIndex++;
            }
    
            // Auto-size columns to fit the contents
            foreach (range('A', 'B') as $columnID) {
                $sheet->getColumnDimension($columnID)->setAutoSize(true);
            }

            // Assume 'cfirstname' and 'clastname' are the names of the input fields in the form
            $candidateFirstName = $_POST['cfirst_name'];
            $candidateLastName = $_POST['clast_name'];

            // Sanitize the names to create a valid filename
            $sanitizedFirstName = preg_replace('/[^a-zA-Z0-9_-]/', '', $candidateFirstName);
            $sanitizedLastName = preg_replace('/[^a-zA-Z0-9_-]/', '', $candidateLastName);

            // Combine first and last name to create the filename
            $filename = $sanitizedFirstName . ' ' . $sanitizedLastName . '-Paperwork.xlsx';
    
            // Create and save the Excel file
            $writer = new Xlsx($spreadsheet);
            // $filename = 'formdata.xlsx';
            $writer->save($filename);


            $userEmail = $_POST['cemail'];

                // Send email notification
                $mail = new PHPMailer(true);

        try {
            $mail = new PHPMailer(true);
        
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'saranraj50540@gmail.com';
            $mail->Password = 'duxaotaxptdtniez';
            $mail->SMTPSecure = 'ssl';
            $mail->Port = 465;


            // Send confirmation email to the user
            $mail->clearAddresses();
            $mail->addAddress($userEmail); // User email address
            $mail->Subject = 'Feedback Submitted Successfully';
            $mail->Body = 'Hi,<br><br>We have received your request to unsubscribe from our services and will ensure you no longer receive communications from us. If you need further assistance or are seeking new opportunities, please email us at csm@vdartinc.com. We are happy to help.' .
              '<br><br><div style="margin-left: 10px;"><img src="https://myfiles.space/user_files/215797_86b4cb4ecfd8b641/215797_custom_files/img1715867137.png" alt="VDart Logo" style="width:100px;height:auto;margin-top:20px;float:left;">' .
              '<span style="font-size: 12px; margin-left: 30px; font-weight: bold; font-family: Arial, sans-serif; color: #333;">Regards,<br><span style="font-weight: bold; margin-left: 30px;">Team VDart,</span><br><a href="http://www.vdart.com" target="_blank" style="color: #007bff; text-decoration: none; margin-left: 30px;">www.vdart.com</a></span></div>' .
              '<br><img src="https://myfiles.space/user_files/215797_86b4cb4ecfd8b641/215797_custom_files/img1715867137.jpeg" alt="VDart Banner" style="width:500px;height:auto;margin-top:20px;">' .
              '<br><span style="font-size:11px;line-height:110%;color:#BFBFBF;">The content of this email is confidential and intended for the recipient specified in the message only. It is strictly forbidden to share any part of this message with any third party, without the written consent of the sender. If you received this message by mistake, please reply to this message and follow with its deletion, so that we can ensure such a mistake does not occur in the future.</span>';

            
            //Recipients
            // $mail->setFrom('saranraj50540@gmail.com');
            // $mail->addAddress($userEmail);  // Add a recipient

            // Attach the generated Excel file
            $mail->addAttachment($filename);

            // Content
            // $mail->isHTML(true);
            // $mail->Subject = 'New Form Submission';
            // $mail->Body    = 'A new form has been submitted. Please find the attached Excel file with the details.';

            $mail->send();
            echo 'Email has been sent';

        } catch (Exception $e) {
            echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
        }
    
            // Offer the file for download
            header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
            header('Content-Disposition: attachment; filename="' . $filename . '";');
            readfile($filename);
    
            // Remove the file after download
            unlink($filename);
            exit();
        } 
        else {
            echo "Error fetching data.";
        }
 
    } else {
        echo "Error: " . $stmt->error;
    }


    
$stmt->close();
$conn->close();



?>




