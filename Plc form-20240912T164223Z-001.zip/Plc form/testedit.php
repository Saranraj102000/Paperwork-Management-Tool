
<?php
$servername = "localhost";  // Change if using a different host
$username = "root"; // Replace with your database username
$password = ""; // Replace with your database password
$dbname = "formdata"; // Replace with your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>

<?php


// Check if ID is set in the URL
if (isset($_GET['id'])) {
    $id = htmlspecialchars($_GET['id']);

    // Prepare the SQL query to fetch the record
    $sql = "SELECT * FROM paperworkdetails WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();

    // Check if the record exists
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        // Now $row contains the data of the specific record
    } else {
        echo "Record not found.";
        exit;
    }

    $stmt->close();
} else {
    echo "No ID specified.";
    exit;
}
?>

<!DOCTYPE html>
<!--=== Coding by CodingLab | www.codinglabweb.com === -->
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!----======== CSS ======== -->
    <link rel="stylesheet" href="updatestyles.css">
    <link rel="stylesheet" href="https://use.typekit.net/xxxxxx.css"> <!-- Replace with your actual link -->
    <!----===== Iconscout CSS ===== -->
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css"> <!-- FontAwesome Icons -->


    <title>Responsive Registration Form </title>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
     
</head>
<style>
    
    /* New Back Button Styles */
/* Style for the back button */
.back-button {
    display: flex;
    align-items: center;
    background: linear-gradient(135deg, #6e8efb, #a777e3); /* Gradient background */
    color: white;
    padding: 10px 20px;
    border: none;
    border-radius: 8px;
    text-decoration: none;
    font-size: 16px;
    transition: background-color 0.3s, transform 0.3s;
    position: absolute;
    top: 20px;
    left: 20px;
    z-index: 1000; /* Ensure it appears above other content */
}

.back-button i {
    margin-right: 8px; /* Space between icon and text */
}

.back-button:hover {
    background: linear-gradient(135deg, #a777e3, #6e8efb); /* Reverse gradient on hover */
    transform: translateY(-2px);
}

.back-button:active {
    transform: translateY(0);
}


/* Button styling */
.logout-button {
    position: absolute;
    top: 20px;
    right: 20px;
    background: linear-gradient(135deg, #ff7e67, #ff5743);
    color: white;
    padding: 10px 20px;
    border: none;
    border-radius: 8px;
    display: flex;
    align-items: center;
    text-decoration: none;
    font-size: 16px;
    transition: background-color 0.3s, transform 0.3s;
    z-index: 1000; /* Ensure it appears above other content */
}

.logout-button i {
    margin-right: 8px; /* Space between icon and text */
}

.logout-button:hover {
    background: linear-gradient(135deg, #ff5743, #ff7e67);
    transform: translateY(-2px);
}

.logout-button:active {
    transform: translateY(0);
}
.header-container {
    display: inline-flex;
    align-items: center;
}
body {
    font-family: Arial, sans-serif;
    background: linear-gradient(45deg, #fdbb2d, #22c1c3, #fdbb2d);
    background-size: 300% 300%;
    color: #333;
    margin: 0;
    padding: 0;
    animation: gradientAnimation 3s ease infinite;
}

/* @keyframes gradientAnimation {
    0% { background-position: 0% 50%; }
    50% { background-position: 100% 50%; }
    100% { background-position: 0% 50%; }
} */

.container form{
    position: relative;
    margin-top: 16px;
    min-height: 3200px;
    background-color: #fff;
    overflow: hidden;
}
</style>
<body>
    <div class="container scrollable-container">
    <center>
        <header>
            <img src="images.png" alt="Image" style="width: 50px; height: auto; margin-right: 5px; vertical-align: middle; margin-top: -10px;">
            <span style="font-size: 24px; color: #000;">Edit Paperwork</span>
        </header>
    </center>



<br>
<?php
    // Fetch existing data to pre-fill the form (if needed)
    $id = isset($_GET['id']) ? $_GET['id'] : '';
    ?>
        <form id="myForm" method="POST" action="updateitem.php" enctype="multipart/form-data">
        <input type="hidden" name="id" value="<?php echo htmlspecialchars($id); ?>">
            <div class="form first">
            <div class="details personal">
    <span class="title">Consultant Details</span>

    <div class="fields">
        <div class="input-field">
            <label for="cfirstname">First Name:</label>
            <input type="text" name="cfirstname" value="<?php echo htmlspecialchars($row['cfirstname']); ?>" >
        </div>

        <div class="input-field">
            <label for="clastname">Last Name:</label>
            <input type="text" name="clastname" value="<?php echo htmlspecialchars($row['clastname']); ?>" >
        </div>

        <div class="input-field">
            <label for="ceipal_id">CEIPAL ID:</label>
            <input type="text" name="ceipal_id" value="<?php echo htmlspecialchars($row['ceipalid']); ?>" >
        </div>

        <div class="input-field">
            <label for="clinkedin_url">LinkedIn URL:</label>
            <input type="text" name="clinkedin_url" value="<?php echo htmlspecialchars($row['clinkedinurl']); ?>" >
        </div>

        <div class="input-field">
            <label for="cdob">Date of Birth:</label>
            <input type="text" name="cdob" value="<?php echo htmlspecialchars($row['cdob']); ?>" >
        </div>

        <div class="input-field">
            <label for="cmobilenumber">Mobile Number:</label>
            <input type="text" name="cmobilenumber" value="<?php echo htmlspecialchars($row['cmobilenumber']); ?>" >
        </div>

        <div class="input-field">
            <label for="cemail">Email:</label>
            <input type="text" name="cemail" value="<?php echo htmlspecialchars($row['cemail']); ?>" >
        </div>

        <div class="input-field">
            <label for="clocation">Location:</label>
            <input type="text" name="clocation" value="<?php echo htmlspecialchars($row['clocation']); ?>" >
        </div>

        <div class="input-field">
            <label for="chomeaddress">Home Address:</label>
            <input type="text" name="chomeaddress" value="<?php echo htmlspecialchars($row['chomeaddress']); ?>" >
        </div>

        <div class="input-field">
            <label for="cssn">SSN:</label>
            <input type="text" name="cssn" value="<?php echo htmlspecialchars($row['cssn']); ?>" >
        </div>

        <div class="input-field">
            <label for="cwork_authorization_status">Work Authorization Status:</label>
            <input type="text" name="cwork_authorization_status" value="<?php echo htmlspecialchars($row['cwork_authorization_status']); ?>" >
        </div>

        <div class="input-field">
            <label for="cv_validate_status">CV Validation Status:</label>
            <input type="text" name="cv_validate_status" value="<?php echo htmlspecialchars($row['cv_validate_status']); ?>" >
        </div>

        <div class="input-field">
            <label for="ccertifications">Certifications:</label>
            <input type="text" name="ccertifications" value="<?php echo htmlspecialchars($row['ccertifications']); ?>" >
        </div>

        <div class="input-field">
            <label for="coverall_experience">Overall Experience:</label>
            <input type="text" name="coverall_experience" value="<?php echo htmlspecialchars($row['coverall_experience']); ?>" >
        </div>

        <div class="input-field">
            <label for="crecent_job_title">Recent Job Title:</label>
            <input type="text" name="crecent_job_title" value="<?php echo htmlspecialchars($row['crecent_job_title']); ?>" >
        </div>

        <div class="input-field">
            <label for="ccandidate_source">Candidate Source:</label>
            <input type="text" name="ccandidate_source" value="<?php echo htmlspecialchars($row['ccandidate_source']); ?>" >
        </div>

        <div class="input-field">
            <label for="cresume_attached">Resume Attached:</label>
            <input type="text" name="cresume_attached" value="<?php echo htmlspecialchars($row['cresume_attached']); ?>" >
        </div>

        <div class="input-field">
            <label for="cphoto_id_attached">Photo ID Attached:</label>
            <input type="text" name="cphoto_id_attached" value="<?php echo htmlspecialchars($row['cphoto_id_attached']); ?>" >
        </div>

        <div class="input-field">
            <label for="cwa_attached">Work Authorization Attached:</label>
            <input type="text" name="cwa_attached" value="<?php echo htmlspecialchars($row['cwa_attached']); ?>" >
        </div>

        <div class="input-field">
            <label for="cany_other_specify">Any Other (Specify):</label>
            <input type="text" name="cany_other_specify" value="<?php echo htmlspecialchars($row['cany_other_specify']); ?>" >
        </div>
    </div>
</div>


            <br><br>
            <div>
    <span class="title">Employer Details</span>
    <div class="fields">
        <div class="input-field">
            <label for="cemployer_own_corporation">Employer Own Corporation:</label>
            <input type="text" name="cemployer_own_corporation" value="<?php echo htmlspecialchars($row['employer_own_corporation']); ?>" ><br>
        </div>

        <div class="input-field">
            <label for="employer_corporation_name">Employer Corporation Name:</label>
            <input type="text" name="employer_corporation_name" value="<?php echo htmlspecialchars($row['employer_corporation_name']); ?>" >
        </div>

        <div class="input-field">
            <label for="fed_id_number">Federal ID Number:</label>
            <input type="text" name="fed_id_number" value="<?php echo htmlspecialchars($row['fed_id_number']); ?>" >
        </div>

        <div class="input-field">
            <label for="contact_person_name">Contact Person Name:</label>
            <input type="text" name="contact_person_name" value="<?php echo htmlspecialchars($row['contact_person_name']); ?>" >
        </div>

        <div class="input-field">
            <label for="contact_person_designation">Contact Person Designation:</label>
            <input type="text" name="contact_person_designation" value="<?php echo htmlspecialchars($row['contact_person_designation']); ?>" >
        </div>

        <div class="input-field">
            <label for="contact_person_address">Contact Person Address:</label>
            <input type="text" name="contact_person_address" value="<?php echo htmlspecialchars($row['contact_person_address']); ?>" >
        </div>

        <div class="input-field">
            <label for="contact_person_phone_number">Contact Person Phone Number:</label>
            <input type="text" name="contact_person_phone_number" value="<?php echo htmlspecialchars($row['contact_person_phone_number']); ?>" >
        </div>

        <div class="input-field">
            <label for="contact_person_extension_number">Contact Person Extension Number:</label>
            <input type="text" name="contact_person_extension_number" value="<?php echo htmlspecialchars($row['contact_person_extension_number']); ?>" >
        </div>

        <div class="input-field">
            <label for="contact_person_email_id">Contact Person Email ID:</label>
            <input type="text" name="contact_person_email_id" value="<?php echo htmlspecialchars($row['contact_person_email_id']); ?>" >
        </div>

        <div class="input-field">
            <label for="benchsale_recruiter_name">Benchsale Recruiter Name:</label>
            <input type="text" name="benchsale_recruiter_name" value="<?php echo htmlspecialchars($row['benchsale_recruiter_name']); ?>" >
        </div>

        <div class="input-field">
            <label for="benchsale_recruiter_phone_number">Benchsale Recruiter Phone Number:</label>
            <input type="text" name="benchsale_recruiter_phone_number" value="<?php echo htmlspecialchars($row['benchsale_recruiter_phone_number']); ?>" >
        </div>

        <div class="input-field">
            <label for="benchsale_recruiter_extension_number">Benchsale Recruiter Extension Number:</label>
            <input type="text" name="benchsale_recruiter_extension_number" value="<?php echo htmlspecialchars($row['benchsale_recruiter_extension_number']); ?>" >
        </div>

        <div class="input-field">
            <label for="benchsale_recruiter_emailid">Benchsale Recruiter Email ID:</label>
            <input type="text" name="benchsale_recruiter_emailid" value="<?php echo htmlspecialchars($row['benchsale_recruiter_email_id']); ?>" >
        </div>

        <div class="input-field">
            <label for="website_link">Website Link:</label>
            <input type="text" name="website_link" value="<?php echo htmlspecialchars($row['website_link']); ?>" >
        </div>

        <div class="input-field">
            <label for="employer_linkedin_url">Employer LinkedIn URL:</label>
            <input type="text" name="employer_linkedin_url" value="<?php echo htmlspecialchars($row['employer_linkedin_url']); ?>" >
        </div>
    </div>         
</div>


            <br>
            <div>
    <span class="title">Additional Employer Details</span>
    <div class="fields">
        <div class="input-field">
            <label for="employer_type">Employer Type:</label>
            <input type="text" name="employer_type" value="<?php echo htmlspecialchars($row['employer_type']); ?>" >
        </div>

        <div class="input-field">
            <label for="employer_corporation_name1">Employer Corporation Name (Alternate):</label>
            <input type="text" name="employer_corporation_name1" value="<?php echo htmlspecialchars($row['employer_corporation_name1']); ?>" >
        </div>

        <div class="input-field">
            <label for="fed_id_number1">Federal ID Number (Alternate):</label>
            <input type="text" name="fed_id_number1" value="<?php echo htmlspecialchars($row['fed_id_number1']); ?>" >
        </div>

        <div class="input-field">
            <label for="contact_person_name1">Contact Person Name (Alternate):</label>
            <input type="text" name="contact_person_name1" value="<?php echo htmlspecialchars($row['contact_person_name1']); ?>" >
        </div>

        <div class="input-field">
            <label for="contact_person_designation1">Contact Person Designation (Alternate):</label>
            <input type="text" name="contact_person_designation1" value="<?php echo htmlspecialchars($row['contact_person_designation1']); ?>" >
        </div>

        <div class="input-field">
            <label for="contact_person_address1">Contact Person Address (Alternate):</label>
            <input type="text" name="contact_person_address1" value="<?php echo htmlspecialchars($row['contact_person_address1']); ?>" >
        </div>

        <div class="input-field">
            <label for="contact_person_phone_number1">Contact Person Phone Number (Alternate):</label>
            <input type="text" name="contact_person_phone_number1" value="<?php echo htmlspecialchars($row['contact_person_phone_number1']); ?>" >
        </div>

        <div class="input-field">
            <label for="contact_person_extension_number1">Contact Person Extension Number (Alternate):</label>
            <input type="text" name="contact_person_extension_number1" value="<?php echo htmlspecialchars($row['contact_person_extension_number1']); ?>" >
        </div>

        <div class="input-field">
            <label for="contact_person_email_id1">Contact Person Email ID (Alternate):</label>
            <input type="text" name="contact_person_email_id1" value="<?php echo htmlspecialchars($row['contact_person_email_id1']); ?>" >
        </div>
    </div>         
</div>




            <br>
            <div>
    <span class="title">Collaboration Details</span>
    <div class="fields">
        <div class="input-field">
            <label for="collaboration_collaborate">Collaboration:</label>
            <input type="text" name="collaboration_collaborate" value="<?php echo htmlspecialchars($row['collaboration_collaborate']); ?>" >
        </div>

        <div class="input-field">
            <label for="delivery_manager">Delivery Manager:</label>
            <input type="text" name="delivery_manager" value="<?php echo htmlspecialchars($row['delivery_manager']); ?>" >
        </div>

        <div class="input-field">
            <label for="delivery_account_lead">Delivery Account Lead:</label>
            <input type="text" name="delivery_account_lead" value="<?php echo htmlspecialchars($row['delivery_account_lead']); ?>" >
        </div>

        <div class="input-field">
            <label for="team_lead">Team Lead:</label>
            <input type="text" name="team_lead" value="<?php echo htmlspecialchars($row['team_lead']); ?>" >
        </div>

        <div class="input-field">
            <label for="associate_team_lead">Associate Team Lead:</label>
            <input type="text" name="associate_team_lead" value="<?php echo htmlspecialchars($row['associate_team_lead']); ?>" >
        </div>
    </div>         
</div>



                <br>
                <div>
    <span class="title">Recruiter Details</span>
    <div class="fields">

        <div class="input-field">
            <label for="business_unit">Business Unit:</label>
            <input type="text" name="business_unit" value="<?php echo htmlspecialchars($row['business_unit']); ?>" >
        </div>

        <div class="input-field">
            <label for="client_account_lead">Client Account Lead:</label>
            <input type="text" name="client_account_lead" value="<?php echo htmlspecialchars($row['client_account_lead']); ?>" >
        </div>

        <div class="input-field">
            <label for="associate_director_delivery">Associate Director of Delivery:</label>
            <input type="text" name="associate_director_delivery" value="<?php echo htmlspecialchars($row['associate_director_delivery']); ?>" >
        </div>

        <div class="input-field">
            <label for="delivery_manager1">Delivery Manager 1:</label>
            <input type="text" name="delivery_manager1" value="<?php echo htmlspecialchars($row['delivery_manager1']); ?>" >
        </div>

        <div class="input-field">
            <label for="delivery_account_lead1">Delivery Account Lead 1:</label>
            <input type="text" name="delivery_account_lead1" value="<?php echo htmlspecialchars($row['delivery_account_lead1']); ?>" >
        </div>

        <div class="input-field">
            <label for="team_lead1">Team Lead 1:</label>
            <input type="text" name="team_lead1" value="<?php echo htmlspecialchars($row['team_lead1']); ?>" >
        </div>

        <div class="input-field">
            <label for="associate_team_lead1">Associate Team Lead 1:</label>
            <input type="text" name="associate_team_lead1" value="<?php echo htmlspecialchars($row['associate_team_lead1']); ?>" >
        </div>

        <div class="input-field">
            <label for="recruiter_name">Recruiter Name:</label>
            <input type="text" name="recruiter_name" value="<?php echo htmlspecialchars($row['recruiter_name']); ?>" >
        </div>

        <div class="input-field">
            <label for="recruiter_employee_id">Recruiter Employee ID:</label>
            <input type="text" name="recruiter_employee_id" value="<?php echo htmlspecialchars($row['recruiter_employee_id']); ?>" >
        </div>

        <div class="input-field">
            <label for="pt_support">PT Support:</label>
            <input type="text" name="pt_support" value="<?php echo htmlspecialchars($row['pt_support']); ?>" >
        </div>

        <div class="input-field">
            <label for="pt_ownership">PT Ownership:</label>
            <input type="text" name="pt_ownership" value="<?php echo htmlspecialchars($row['pt_ownership']); ?>" >
        </div>

        <div class="input-field">
            <label for="coe_non_coe">COE/Non-COE:</label>
            <input type="text" name="coe_non_coe" value="<?php echo htmlspecialchars($row['coe_non_coe']); ?>" >
        </div>

    </div>         
</div>



            <br>
            <div>
    <span class="title">Project Details</span>
    <div class="fields">

        <div class="input-field">
            <label for="geo">Geography:</label>
            <input type="text" name="geo" value="<?php echo htmlspecialchars($row['geo']); ?>" >
        </div>

        <div class="input-field">
            <label for="entity">Entity:</label>
            <input type="text" name="entity" value="<?php echo htmlspecialchars($row['entity']); ?>" >
        </div>

        <div class="input-field">
            <label for="client">Client:</label>
            <input type="text" name="client" value="<?php echo htmlspecialchars($row['client']); ?>" >
        </div>
        
        <div class="input-field">
            <label for="client_manager">Client Manager:</label>
            <input type="text" name="client_manager" value="<?php echo htmlspecialchars($row['client_manager']); ?>" >
        </div>

        <div class="input-field">
            <label for="client_manager_email_id">Client Manager Email ID:</label>
            <input type="text" name="client_manager_email_id" value="<?php echo htmlspecialchars($row['client_manager_email_id']); ?>" >
        </div>

        <div class="input-field">
            <label for="end_client">End Client:</label>
            <input type="text" name="end_client" value="<?php echo htmlspecialchars($row['end_client']); ?>" >
        </div>

        <div class="input-field">
            <label for="business_track">Business Track:</label>
            <input type="text" name="business_track" value="<?php echo htmlspecialchars($row['business_track']); ?>" >
        </div>

        <div class="input-field">
            <label for="industry">Industry:</label>
            <input type="text" name="industry" value="<?php echo htmlspecialchars($row['industry']); ?>" >
        </div>

        <div class="input-field">
            <label for="experience_in_expertise_role">Experience in Expertise Role:</label>
            <input type="text" name="experience_in_expertise_role" value="<?php echo htmlspecialchars($row['experience_in_expertise_role']); ?>" >
        </div>

        <div class="input-field">
            <label for="job_code">Job Code:</label>
            <input type="text" name="job_code" value="<?php echo htmlspecialchars($row['job_code']); ?>" >
        </div>

        <div class="input-field">
            <label for="job_title">Job Title:</label>
            <input type="text" name="job_title" value="<?php echo htmlspecialchars($row['job_title']); ?>" >
        </div>

        <div class="input-field">
            <label for="primary_skill">Primary Skill:</label>
            <input type="text" name="primary_skill" value="<?php echo htmlspecialchars($row['primary_skill']); ?>" >
        </div>

        <div class="input-field">
            <label for="secondary_skill">Secondary Skill:</label>
            <input type="text" name="secondary_skill" value="<?php echo htmlspecialchars($row['secondary_skill']); ?>" >
        </div>

        <div class="input-field">
            <label for="term">Term:</label>
            <input type="text" name="term" value="<?php echo htmlspecialchars($row['term']); ?>" >
        </div>

        <div class="input-field">
            <label for="duration">Duration:</label>
            <input type="text" name="duration" value="<?php echo htmlspecialchars($row['duration']); ?>" >
        </div>

        <div class="input-field">
            <label for="project_location">Project Location:</label>
            <input type="text" name="project_location" value="<?php echo htmlspecialchars($row['project_location']); ?>" >
        </div>

        <div class="input-field">
            <label for="start_date">Start Date:</label>
            <input type="text" name="start_date" value="<?php echo htmlspecialchars($row['start_date']); ?>" >
        </div>

        <div class="input-field">
            <label for="end_date">End Date:</label>
            <input type="text" name="end_date" value="<?php echo htmlspecialchars($row['end_date']); ?>" >
        </div>

        <div class="input-field">
            <label for="payrate">Payrate:</label>
            <input type="text" name="payrate" value="<?php echo htmlspecialchars($row['payrate']); ?>" >
        </div>

        <div class="input-field">
            <label for="clientrate">Client Rate:</label>
            <input type="text" name="clientrate" value="<?php echo htmlspecialchars($row['clientrate']); ?>" >
        </div>

        <div class="input-field">
            <label for="margin">Margin:</label>
            <input type="text" name="margin" value="<?php echo htmlspecialchars($row['margin']); ?>" >
        </div>

        <div class="input-field">
            <label for="vendor_fee">Vendor Fee:</label>
            <input type="text" name="vendor_fee" value="<?php echo htmlspecialchars($row['vendor_fee']); ?>" >
        </div>

        <div class="input-field">
            <label for="margin_deviation_approval">Margin Deviation Approval:</label>
            <input type="text" name="margin_deviation_approval" value="<?php echo htmlspecialchars($row['margin_deviation_approval']); ?>" >
        </div>

        <div class="input-field">
            <label for="margin_deviation_reason">Margin Deviation Reason:</label>
            <input type="text" name="margin_deviation_reason" value="<?php echo htmlspecialchars($row['margin_deviation_reason']); ?>" >
        </div>

        <div class="input-field">
            <label for="ratecard_adherence">Ratecard Adherence:</label>
            <input type="text" name="ratecard_adherence" value="<?php echo htmlspecialchars($row['ratecard_adherence']); ?>" >
        </div>

        <div class="input-field">
            <label for="ratecard_deviation_reason">Ratecard Deviation Reason:</label>
            <input type="text" name="ratecard_deviation_reason" value="<?php echo htmlspecialchars($row['ratecard_deviation_reason']); ?>" >
        </div>

        <div class="input-field">
            <label for="ratecard_deviation_approved">Ratecard Deviation Approved:</label>
            <input type="text" name="ratecard_deviation_approved" value="<?php echo htmlspecialchars($row['ratecard_deviation_approved']); ?>" >
        </div>

        <div class="input-field">
            <label for="payment_term">Payment Term:</label>
            <input type="text" name="payment_term" value="<?php echo htmlspecialchars($row['payment_term']); ?>" >
        </div>

        <div class="input-field">
            <label for="payment_term_approval">Payment Term Approval:</label>
            <input type="text" name="payment_term_approval" value="<?php echo htmlspecialchars($row['payment_term_approval']); ?>" >
        </div>

        <div class="input-field">
            <label for="payment_term_deviation_reason">Payment Term Deviation Reason:</label>
            <input type="text" name="payment_term_deviation_reason" value="<?php echo htmlspecialchars($row['payment_term_deviation_reason']); ?>" >
        </div>

        <div class="input-field">
            <label for="type">Type:</label>
            <input type="text" name="type" value="<?php echo htmlspecialchars($row['type']); ?>" >
        </div>

        <!-- Add hidden field for record ID -->
        <input type="hidden" name="record_id" value="<?php echo htmlspecialchars($row['id']); ?>">

    </div>         
</div>


                

                <div class="input-field">
                    <button type="submit">Update</button>
                </div> 

            </div>   
        </div>
    </form>
</div>

<script src="script.js"></script>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script type="text/javascript">
        document.getElementById('myForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent the form from submitting immediately

    // Show confirmation dialog
    Swal.fire({
        title: 'Are you sure?',
        text: "Do you want to submit the form?",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, submit it!'
    }).then((result) => {
        if (result.isConfirmed) {
            // Show loading spinner
            Swal.fire({
                title: 'Submitting...',
                text: 'Please wait while we process your request.',
                didOpen: () => {
                    Swal.showLoading(); // Show the loading spinner
                },
                allowOutsideClick: false,
                allowEscapeKey: false
            });

            // Use FormData to handle the form data
            const form = event.target;
            const formData = new FormData(form);

            fetch(form.action, {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                // Hide the loading spinner and show success or error message
                Swal.close(); // Close the loading spinner
                if (data.status === 'success') {
                    Swal.fire({
                        title: 'Submitted!',
                        text: data.message,
                        icon: 'success'
                    }).then(() => {
                        // Reload the page after successful submission
                        window.location.href = 'history.php';
                    });
                } else {
                    Swal.fire({
                        title: 'Error!',
                        text: data.message,
                        icon: 'error'
                    });
                }
            })
            .catch(error => {
                // Hide the loading spinner and show error message
                Swal.close(); // Close the loading spinner
                Swal.fire({
                    title: 'Error!',
                    text: 'An error occurred while submitting the form.',
                    icon: 'error'
                });
            });
        }
    });
});

    </script>

</body>
</html>