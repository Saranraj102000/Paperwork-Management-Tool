<?php

$servername = "localhost";
$username = "root";
$password = "";  // replace with your database password
$dbname = "formdata";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


require 'vendor/autoload.php';  // Include the PHPSpreadsheet library

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Border;
use PhpOffice\PhpSpreadsheet\Style\Fill;

if (isset($_GET['id'])) {
    $recordId = intval($_GET['id']);
    
    // Database connection (assuming $conn is your database connection)
    $sql = "SELECT * FROM paperworkdetails WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $recordId);

    if ($stmt->execute()) {
        $result = $stmt->get_result();
        
        if ($result && $row = $result->fetch_assoc()) {
            // Create a new Spreadsheet object
            $spreadsheet = new Spreadsheet();
            $sheet = $spreadsheet->getActiveSheet();

            // Set headings
            $sheet->mergeCells('A1:B1'); // Merge A1 and B1 for the heading
            $sheet->setCellValue('A1', 'CONSULTANT DETAILS');
            $sheet->getStyle('A1')->getFont()->setBold(true);
            $sheet->getStyle('A1')->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
            $sheet->getStyle('A1')->getFill()->setFillType(Fill::FILL_SOLID)->getStartColor()->setARGB('FFFF00'); // Yellow background
            $sheet->getStyle('A1')->getBorders()->getAllBorders()->setBorderStyle(Border::BORDER_MEDIUM); // Thick borders for heading

            // Field name mapping for more user-friendly labels
            $fieldMapping = [
                'cfirstname' => 'Candidate First Name',
                'clastname' => 'Candidate Last Name',
                'ceipalid' => 'CEIPAL Applicant ID',
                'clinkedinurl' => 'Candidate Linkedin URL',
                'cdob' => 'Date of Birth (DD-MMM)',
                'cmobilenumber' => 'Phone Number',
                'cemail' => 'Email ID',
                'clocation' => 'Location (City, State)',
                'chomeaddress' => 'Home Address',
                'cssn' => 'SSN Number (Last 4 Digits Only) / SIN Number / Cedula ID',
                'cwork_authorization_status' => 'Work Authorization Status',
                'cv_validate_status' => 'V-Validated Status(Applicable only for H1B)',
                'ccertifications' => 'Certifications (If Yes please enter the proper certification details)',
                'coverall_experience' => 'Overall Experience',
                'crecent_job_title' => 'Recent Job Title / Role (Current role)',
                'ccandidate_source' => 'Candidate Source',
                'cresume_attached' => 'Resume Attached (Yes / No)',
                'cphoto_id_attached' => 'Photo ID Attached (Yes/No)',
                'cwa_attached' => 'WA Attached (Yes/No)',
                'cany_other_specify' => 'Any Other Specify',
                'employer_own_corporation' => 'Own Corporation',
                'employer_corporation_name' => 'Employer Corporation Name',
                'fed_id_number' => 'FED ID Number / Tax Number',
                'contact_person_name' => 'Contact Person Name (Signing Authority)',
                'contact_person_designation' => 'Contact Person Designation',
                'contact_person_address' => 'Contact person Address',
                'contact_person_phone_number' => 'Contact Person Phone Number',
                'contact_person_extension_number' => 'Contact Person Extn.Number',
                'contact_person_email_id' => 'Contact Person  Email ID',
                'benchsale_recruiter_name' => 'Bench Sale Recruiter Name',
                'benchsale_recruiter_phone_number' => 'Bench Sale Recruiter Phone Number',
                'benchsale_recruiter_extension_number' => 'Bench Sale Recruiter Extn Number',
                'benchsale_recruiter_email_id' => 'Bench Sale Recruiter Email Id',
                'website_link' => 'Web Site',
                'employer_linkedin_url' => 'Employer LinkedIn URL',
                'employer_type' => 'Employer Type',
                'employer_corporation_name1' => 'Employer Corporation Name',
                'fed_id_number1' => 'FED ID Number / Tax Number',
                'contact_person_name1' => 'Contact Person Name (Signing Authority)',
                'contact_person_designation1' => 'Contact Person Designation',
                'contact_person_address1' => 'Contact Person Address',
                'contact_person_phone_number1' => 'Contact Person Phone Number',
                'contact_person_extension_number1' => 'Contact Person Extn.Number',
                'contact_person_email_id1' => 'Contact Person  Email ID',
                'collaboration_collaborate' => 'Collaborate',
                'delivery_manager' => 'Delivery Manager - Collaboration',
                'delivery_account_lead' => 'Delivery Account Lead - Collaboration',
                'team_lead' => 'Team Lead - Collaboration',
                'associate_team_lead' => 'Lead Recruiter - Collaboration',
                'business_unit' => 'Business Unit',
                'client_account_lead' => 'Business Unit',
                'associate_director_delivery' => 'Associate Director Delivery',
                'delivery_manager1' => 'Delivery Manager',
                'delivery_account_lead1' => 'Delivery Account Lead',
                'team_lead1' => 'Team Lead',
                'associate_team_lead1' => 'Lead Recruiter',
                'recruiter_name' => 'Recruiter Name (As per HR Record)',
                'recruiter_employee_id' => 'Recruiter Emp ID',
                'pt_support' => 'PT Support',
                'pt_ownership' => 'PT Ownership',
                'coe_non_coe' => 'Any Other (Specify Like COE/Non-COE)',
                'geo' => 'GEO',
                'entity' => 'Entity',
                'client' => 'Client',
                'client_manager' => 'Client Manager',
                'client_manager_email_id' => 'Client Manager Email ID',
                'end_client' => 'End Client',
                'business_track' => 'Business Track',
                'industry' => 'Industry',
                'experience_in_expertise_role' => 'Experience in Expertise role|Hands on',
                'job_code' => 'Job Code',
                'job_title' => 'Job Title / Role',
                'primary_skill' => 'Primary Skill (Candidate)',
                'secondary_skill' => 'Secondary Skill (Candidate)',
                'term' => 'Term',
                'duration' => 'Duration',
                'project_location' => 'Project Location',
                'start_date' => 'Start Date (DD-MMM-YYYY)',
                'end_date' => 'End Date (DD-MMM-YYYY) / Tentative',
                'payrate' => 'Pay Rate / Salary',
                'clientrate' => 'Client Rate / Salary',
                'margin' => 'Margin',
                'vendor_fee' => 'Additional Vendor Fee (If applicable)',
                'margin_deviation_approval' => 'Margin Deviation Approval (Yes/No)',
                'margin_deviation_reason' => 'Margin Deviation Reason',
                'ratecard_adherence' => 'Rate Card Adherence(Yes/No)',
                'ratecard_deviation_reason' => 'Rate Card Deviation Reason',
                'ratecard_deviation_approved' => 'Rate Card Deviation Approved (Yes/No)',
                'payment_term' => 'Payment Term',
                'payment_term_approval' => 'Payment Term Approval (Yes/No)',
                'payment_term_deviation_reason' => 'Payment Term Deviation Reason',
                'type' => 'Type'
            ];

            $rowIndex = 2;
            foreach ($row as $key => $value) {
                // Handle sections based on specific keys
                if ($key == 'cany_other_specify') {
                    $rowIndex += 2;
                    $sheet->mergeCells('A' . $rowIndex . ':B' . $rowIndex);
                    $sheet->setCellValue('A' . $rowIndex, 'EMPLOYER DETAILS');
                    $sheet->getStyle('A' . $rowIndex)->getFont()->setBold(true);
                    $sheet->getStyle('A' . $rowIndex)->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
                    $sheet->getStyle('A' . $rowIndex)->getFill()->setFillType(Fill::FILL_SOLID)->getStartColor()->setARGB('FFFF00'); // Yellow background
                    $sheet->getStyle('A' . $rowIndex)->getBorders()->getAllBorders()->setBorderStyle(Border::BORDER_THIN);
                    $rowIndex++;
                }
                // Add similar blocks for other sections
                if ($key == 'employer_linkedin_url') {
                    $rowIndex += 2;
                    $sheet->mergeCells('A' . $rowIndex . ':B' . $rowIndex); // Merge for heading
                    $sheet->setCellValue('A' . $rowIndex, 'ADDITIONAL EMPLOYER DETAILS');
                    $sheet->getStyle('A' . $rowIndex)->getFont()->setBold(true);
                    $sheet->getStyle('A' . $rowIndex)->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
                    $sheet->getStyle('A' . $rowIndex)->getFill()->setFillType(Fill::FILL_SOLID)->getStartColor()->setARGB('FFFF00'); // Yellow background
                    $sheet->getStyle('A' . $rowIndex)->getBorders()->getAllBorders()->setBorderStyle(Border::BORDER_THIN); // Thick borders for heading
                    $rowIndex++;
                }
                if ($key == 'contact_person_email_id1') {
                    $rowIndex += 2;
                    $sheet->mergeCells('A' . $rowIndex . ':B' . $rowIndex); // Merge for heading
                    $sheet->setCellValue('A' . $rowIndex, 'COLLABORATION DETAILS');
                    $sheet->getStyle('A' . $rowIndex)->getFont()->setBold(true);
                    $sheet->getStyle('A' . $rowIndex)->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
                    $sheet->getStyle('A' . $rowIndex)->getFill()->setFillType(Fill::FILL_SOLID)->getStartColor()->setARGB('FFFF00'); // Yellow background
                    $sheet->getStyle('A' . $rowIndex)->getBorders()->getAllBorders()->setBorderStyle(Border::BORDER_THIN); // Thick borders for heading
                    $rowIndex++;
                }
                if ($key == 'associate_team_lead') {
                    $rowIndex += 2;
                    $sheet->mergeCells('A' . $rowIndex . ':B' . $rowIndex); // Merge for heading
                    $sheet->setCellValue('A' . $rowIndex, 'RECRUITER DETAILS');
                    $sheet->getStyle('A' . $rowIndex)->getFont()->setBold(true);
                    $sheet->getStyle('A' . $rowIndex)->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
                    $sheet->getStyle('A' . $rowIndex)->getFill()->setFillType(Fill::FILL_SOLID)->getStartColor()->setARGB('FFFF00'); // Yellow background
                    $sheet->getStyle('A' . $rowIndex)->getBorders()->getAllBorders()->setBorderStyle(Border::BORDER_THIN); // Thick borders for heading
                    $rowIndex++;
                }
                if ($key == 'coe_non_coe') {
                    $rowIndex += 2;
                    $sheet->mergeCells('A' . $rowIndex . ':B' . $rowIndex); // Merge for heading
                    $sheet->setCellValue('A' . $rowIndex, 'PROJECT DETAILS');
                    $sheet->getStyle('A' . $rowIndex)->getFont()->setBold(true);
                    $sheet->getStyle('A' . $rowIndex)->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
                    $sheet->getStyle('A' . $rowIndex)->getFill()->setFillType(Fill::FILL_SOLID)->getStartColor()->setARGB('FFFF00'); // Yellow background
                    $sheet->getStyle('A' . $rowIndex)->getBorders()->getAllBorders()->setBorderStyle(Border::BORDER_THIN); // Thick borders for heading
                    $rowIndex++;
                }
                
                // Use the friendly label from the mapping if it exists, otherwise use the original key
                $label = isset($fieldMapping[$key]) ? $fieldMapping[$key] : $key;

                $sheet->setCellValue('A' . $rowIndex, $label);
                $sheet->setCellValue('B' . $rowIndex, $value);
                $sheet->getStyle('A' . $rowIndex . ':B' . $rowIndex)->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
                $sheet->getStyle('A' . $rowIndex . ':B' . $rowIndex)->getBorders()->getAllBorders()->setBorderStyle(Border::BORDER_THIN);
                $rowIndex++;
            }

            // Auto-size columns to fit the contents
            foreach (range('A', 'B') as $columnID) {
                $sheet->getColumnDimension($columnID)->setAutoSize(true);
            }

            // Generate the filename
            $filename = 'Consultant_Paperwork_' . $recordId . '.xlsx';
    
            // Create and save the Excel file
            $writer = new Xlsx($spreadsheet);

            // Output the file to the browser
            header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
            header('Content-Disposition: attachment; filename="' . $filename . '";');
            $writer->save("php://output");
            exit();

        } else {
            echo "Error fetching data.";
        }

    } else {
        echo "Error: " . $stmt->error;
    }

} else {
    echo "Invalid request.";
}

$conn->close();
?>
