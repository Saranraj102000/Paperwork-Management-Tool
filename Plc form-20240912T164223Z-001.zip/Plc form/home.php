<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header('Location: login.php'); // Redirect to login page if not logged in
    exit;
}
?>


<!DOCTYPE html>
<!--=== Coding by CodingLab | www.codinglabweb.com === -->
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!----======== CSS ======== -->
    <link rel="stylesheet" href="homestyles.css">
    <link rel="stylesheet" href="https://use.typekit.net/xxxxxx.css"> <!-- Replace with your actual link -->
    <!----===== Iconscout CSS ===== -->
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css"> <!-- FontAwesome Icons -->
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />

    <title>Responsive Registration Form </title>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
     
</head>
<style>
    /* New Back Button Styles */
/* Style for the back button */
.back-button {
    display: flex;
    align-items: center;
    background: linear-gradient(135deg, #6e8efb, #a777e3); /* Gradient background */
    color: white;
    padding: 10px 20px;
    border: none;
    border-radius: 8px;
    text-decoration: none;
    font-size: 16px;
    transition: background-color 0.3s, transform 0.3s;
    position: absolute;
    top: 20px;
    left: 20px;
    z-index: 1000; /* Ensure it appears above other content */
}

.back-button i {
    margin-right: 8px; /* Space between icon and text */
}

.back-button:hover {
    background: linear-gradient(135deg, #a777e3, #6e8efb); /* Reverse gradient on hover */
    transform: translateY(-2px);
}

.back-button:active {
    transform: translateY(0);
}


/* Button styling */
.logout-button {
    position: absolute;
    top: 20px;
    right: 20px;
    background: linear-gradient(135deg, #ff7e67, #ff5743);
    color: white;
    padding: 10px 20px;
    border: none;
    border-radius: 8px;
    display: flex;
    align-items: center;
    text-decoration: none;
    font-size: 16px;
    transition: background-color 0.3s, transform 0.3s;
    z-index: 1000; /* Ensure it appears above other content */
}

.logout-button i {
    margin-right: 8px; /* Space between icon and text */
}

.logout-button:hover {
    background: linear-gradient(135deg, #ff5743, #ff7e67);
    transform: translateY(-2px);
}

.logout-button:active {
    transform: translateY(0);
}
.header-container {
    display: inline-flex;
    align-items: center;
}
body {
    font-family: Arial, sans-serif;
    background: linear-gradient(45deg, #fdbb2d, #22c1c3, #fdbb2d);
    background-size: 300% 300%;
    color: #333;
    margin: 0;
    padding: 0;
    animation: gradientAnimation 3s ease infinite;
}

/* @keyframes gradientAnimation {
    0% { background-position: 0% 50%; }
    50% { background-position: 100% 50%; }
    100% { background-position: 0% 50%; }
} */


    </style>
<body>
    <div class="container scrollable-container">
    <center>
        <header>
            <img src="images.png" alt="Image" style="width: 50px; height: auto; margin-right: 5px; vertical-align: middle; margin-top: -10px;">
            <span style="font-size: 24px; color: #000;">Paperwork</span>
        </header>
    </center>



        <a href="logout.php" class="logout-button">
            <i class="fa fa-sign-out-alt"></i> Logout
        </a>

        <a href="history.php" class="back-button">
            <i class="fas fa-history"></i> History
        </a>

<br>
        <form id="myForm" method="POST" action="submit.php" enctype="multipart/form-data">
            <div class="form first">
                <div class="details personal">
                    <span class="title">Consultant Details</span>

                    <div class="fields">
                        <div class="input-field">
                            <label>Candidate First Name</label>
                            <input type="text"   name="cfirst_name" >
                        </div>

                        <div class="input-field">
                            <label>Candidate Last Name</label>
                            <input type="text"   name="clast_name" >
                        </div>

                        <div class="input-field">
                            <label>Ceipal Applicant ID</label>
                            <input type="text"   name="ceipal_id" >
                        </div>

                        <div class="input-field">
                            <label>Candidate LinkedIn url</label>
                            <input type="text"   name="clinkedin_url" >
                        </div>

                        <div class="input-field">
                            <label>Date of Birth</label>
                            <input type="date"  name="cdob" >
                        </div>

                        <div class="input-field">
                            <label>Mobile Number</label>
                            <input type="number"  name="cmobilenumber" >
                        </div>

                        <div class="input-field">
                            <label>Email</label>
                            <input type="email"  name="cemail" >
                        </div>

                        <div class="input-field">
                            <label>Location(city,state)</label>
                            <input type="text"   name="clocation" >
                        </div>

                        <div class="input-field">
                            <label>Home Address</label>
                            <input type="text"   name="chomeaddress" >
                        </div>
                        
                        <div class="input-field">
                            <label>SSN number (Last 4digits only)</label>
                            <input type="text"  name="cssn" >
                        </div>

                        <div class="input-field">
                            <label>Work Authorization Status</label>
                            <select name="cwork_authorization_status" >
                                <option disabled selected>Select visa type</option>
                                <option>US Citizen</option>
                                <option>Green Card</option>
                                <option>TN</option>
                                <option>H1B</option>
                                <option>Mexican Citizen</option>
                                <option>Canadian Citizen</option>
                                <option>Canadian Work_Permit</option>
                                <option>Australian Citizen</option>
                                <option>CR Citizen</option>
                                <option>GC EAD</option>
                                <option>OPT EAD</option>
                                <option>H4 EAD</option>
                                <option>CPT</option>
                                <option>Others</option>
                            </select>
                        </div>

                        <div class="input-field">
                            <label>V-Validate Status</label>
                            <select name="cv_validate_status" >
                                <option disabled selected>Select option</option>
                                <option>Genuine</option>
                                <option>Questionable</option>
                                <option>clear</option>
                                <option>Invalid Copy</option>
                                <option>Pending</option>
                            </select>
                        </div>

                        <div class="input-field">
                            <label>Certifications</label>
                            <input type="text"  name="ccertifications" >
                        </div>

                        <div class="input-field">
                            <label>Overall Experience</label>
                            <input type="text"  name="coverall_experience" >
                        </div>

                        <div class="input-field">
                            <label>Recent Job Title</label>
                            <input type="text"  name="crecent_job_title" >
                        </div>

                        <div class="input-field">
                            <label>Candidate Source</label>
                            <select name="ccandidate_source" >
                                <option disabled selected>Select option</option>
                                <option>PT</option>
                                <option>PTR</option>
                                <option>Dice Response</option>
                                <option>CB</option>
                                <option>Monster</option>
                                <option>Dice</option>
                                <option>IDB-Dice</option>
                                <option>IDB-CB</option>
                                <option>IDB-Monster</option>
                                <option>LinkedIn Personal</option>
                                <option>LinkedIn Recruiter Platform</option>
                                <option>LinkedIn Recruiter Platform Response</option>
                                <option>CX Bench</option>
                                <option>Referral Client</option>
                                <option>Vendor Consolidation</option>
                                <option>Referral Vendor</option>
                                <option>Career Portal</option>
                                <option>Indeed</option>
                                <option>Sourcing</option>
                                <option>Rehiring</option>
                                <option>Prohires</option>
                                <option>Zip Recruiter</option>
                                <option>Mass Mail</option>
                                <option>LinkedIn Sourcer Karthik T</option>
                                <option>Social Media</option>
                                <option>SRM</option>
                                
                            </select>
                        </div>

                        <div class="input-field">
                            <label>Resume Attached</label>
                            <select name="cresume_attached">
                                <option disabled selected>Select option</option>
                                <option>Yes</option>
                                <option>No</option>
                            </select>
                        </div>

                        <div class="input-field">
                            <label>Photo-ID Attached</label>
                            <select name="cphoto_id_attached" >
                                <option disabled selected>Select option</option>
                                <option>Yes</option>
                                <option>No</option>
                            </select>
                        </div>

                        <div class="input-field">
                            <label>WA Attached</label>
                            <select name="cwa_attached" >
                                <option disabled selected>Select option</option>
                                <option>Yes</option>
                                <option>No</option>
                            </select>
                        </div>
                        
                        <div class="input-field">
                            <label>Anyother Specify</label>
                            <input type="text"  name="cany_other_specify" >
                        </div>
                    </div>
                </div>

            <br><br>
            <div>
                <span class="title">Employer Details</span>
                    <div class="fields">
                        <div class="input-field">
                            <label>Own Corporation</label>
                            <select name="cemployer_own_corporation" >
                                <option disabled selected>Select option</option>
                                <option>Yes</option>
                                <option>No</option>
                            </select>
                        </div>

                        <div class="input-field">
                            <label>Employer Corporation Name</label>
                            <input type="text"  name="employer_corporation_name" >
                        </div>

                        <div class="input-field">
                            <label>FED ID Number</label>
                            <input type="text"  name="fed_id_number" >
                        </div>

                        <div class="input-field">
                            <label>Contact Person Name(Signing authority)</label>
                            <input type="text"  name="contact_person_name" >
                        </div>

                        <div class="input-field">
                            <label>Contact Person Designation</label>
                            <input type="text"  name="contact_person_designation" >
                        </div>

                        <div class="input-field">
                            <label>Contact Person Address</label>
                            <input type="text"  name="contact_person_address" >
                        </div>

                        <div class="input-field">
                            <label>Contact Person Phone Number</label>
                            <input type="number"  name="contact_person_phone_number" >
                        </div>

                        <div class="input-field">
                            <label>Contact Person Extension Number</label>
                            <input type="number"  name="contact_person_extension_number" >
                        </div>

                        <div class="input-field">
                            <label>Contact Person Email ID</label>
                            <input type="email"  name="contact_person_email_id" >
                        </div>

                        <div class="input-field">
                            <label>Benchsale Recruiter Name</label>
                            <input type="text"  name="benchsale_recruiter_name" >
                        </div>

                        <div class="input-field">
                            <label>Benchsale Recruiter Phone Number</label>
                            <input type="number"  name="benchsale_recruiter_phone_number" >
                        </div>

                        <div class="input-field">
                            <label>Benchsale Recruiter Extension Number</label>
                            <input type="number"  name="benchsale_recruiter_extension_number" >
                        </div>

                        <div class="input-field">
                            <label>Benchsale Recruiter Email ID</label>
                            <input type="email"  name="benchsale_recruiter_extension_number" >
                        </div>

                        <div class="input-field">
                            <label>Website Link</label>
                            <input type="text"  name="website_link" >
                        </div>

                        <div class="input-field">
                            <label>Employer LinkedIn Url</label>
                            <input type="text"  name="employer_linkedin_url" >
                        </div>
                        
                    </div>         
                </div>

            <br><br>
            <div>
                <span class="title">Additional Employer Details</span>
                    <div class="fields">
                        <!-- <div class="input-field">
                            <label>Employer type</label>
                            <input type="text"   name="employer_type" >
                        </div> -->

                        <div class="input-field">
                            <label>Employer Type</label>
                            <select name="employer_type" >
                                <option disabled selected>Select option</option>
                                <option>Vendor Change</option>
                                <option>Vendor Reference</option>
                                <option>NA</option>
                            </select>
                        </div>

                        <div class="input-field">
                            <label>Employer Corporation Name</label>
                            <input type="text"  name="employer_corporation_name1" >
                        </div>

                        <div class="input-field">
                            <label>FED ID Number</label>
                            <input type="text"  name="fed_id_number1" >
                        </div>

                        <div class="input-field">
                            <label>Contact Person Name(Signing authority)</label>
                            <input type="text"  name="contact_person_name1" >
                        </div>

                        <div class="input-field">
                            <label>Contact Person Designation</label>
                            <input type="text"  name="contact_person_designation1" >
                        </div>

                        <div class="input-field">
                            <label>Contact Person Address</label>
                            <input type="text"  name="contact_person_address1" >
                        </div>

                        <div class="input-field">
                            <label>Contact Person Phone Number</label>
                            <input type="number"  name="contact_person_phone_number1" >
                        </div>

                        <div class="input-field">
                            <label>Contact Person Extension Number</label>
                            <input type="number"  name="contact_person_extension_number1" >
                        </div>

                        <div class="input-field">
                            <label>Contact Person Email ID</label>
                            <input type="email"  name="contact_person_email_id1" >
                        </div>
                    </div>         
                </div>



            <br><br>
            <!-- <div>
                <span class="title">Collaboration Details</span>
                    <div class="fields">
                        <div class="input-field">
                            <label>Collaborate</label>
                            <select name="collaboration_collaborate" >
                                <option disabled selected>Select option</option>
                                <option>Yes</option>
                                <option>No</option>
                            </select>
                        </div>

                        <div class="input-field">
                            <label>Delivery Manager</label>
                            <select name="delivery_manager" >
                                <option disabled selected>Select option</option>
                                <option>Amit</option>
                                <option>Abhishek</option>
                                <option>Aditya</option>
                                <option>Abhishek / Aditya</option>
                                <option>Vijay Methani</option>
                                <option>David</option>
                                <option>Devna</option>
                                <option>Don</option>
                                <option>Monse</option>
                                <option>Nambu</option>
                                <option>Narayan</option>
                                <option>Parijat</option>
                                <option>Priscilla</option>
                                <option>Sudip</option>
                                <option>Vinay</option>
                                <option>Prasanth Ravi</option>
                                <option>Sachin Sinha</option>
                                <option>Susan Johnson</option>
                                <option>NA</option>


                            </select>
                        </div>

                        <div class="input-field">
                            <label>Delivery Account Lead</label>
                            <input type="text"  name="delivery_account_lead" >
                        </div>

                        <div class="input-field">
                            <label>Team Lead</label>
                            <input type="text"  name="team_lead" >
                        </div>
                
                        <div class="input-field">
                            <label>Associate Team Lead</label>
                            <input type="text"  name="associate_team_lead" >
                        </div>
                    </div>         
                </div> -->



                <div>
    <span class="title">Collaboration Details</span>
    <div class="fields">
        <div class="input-field">
            <label>Collaborate</label>
            <select name="collaboration_collaborate" id="collaboration_collaborate">
                <option disabled selected>Select option</option>
                <option value="yes">Yes</option>
                <option value="no">No</option>
            </select>
        </div>

        <div class="input-field" id="delivery_manager_field" style="visibility: hidden; height: 0; margin: 0; padding: 0;">
            <label>Delivery Manager</label>
            <select name="delivery_manager">
                <option disabled selected>Select option</option>
                <option>Amit</option>
                <option>Abhishek</option>
                <option>Aditya</option>
                <option>Abhishek / Aditya</option>
                <option>Vijay Methani</option>
                <option>David</option>
                <option>Devna</option>
                <option>Don</option>
                <option>Monse</option>
                <option>Nambu</option>
                <option>Narayan</option>
                <option>Parijat</option>
                <option>Priscilla</option>
                <option>Sudip</option>
                <option>Vinay</option>
                <option>Prasanth Ravi</option>
                <option>Sachin Sinha</option>
                <option>Susan Johnson</option>
                <option>NA</option>
            </select>
        </div>

        <div class="input-field" id="delivery_account_lead_field" style="visibility: hidden; height: 0; margin: 0; padding: 0;">
            <label>Delivery Account Lead</label>
            <input type="text" name="delivery_account_lead">
        </div>

        <div class="input-field" id="team_lead_field" style="visibility: hidden; height: 0; margin: 0; padding: 0;">
            <label>Team Lead</label>
            <input type="text" name="team_lead">
        </div>

        <div class="input-field" id="associate_team_lead_field" style="visibility: hidden; height: 0; margin: 0; padding: 0;">
            <label>Associate Team Lead</label>
            <input type="text" name="associate_team_lead">
        </div>
    </div>
</div>




<script>
    document.getElementById('collaboration_collaborate').addEventListener('change', function() {
        const value = this.value;
        const fields = [
            document.getElementById('delivery_manager_field'),
            document.getElementById('delivery_account_lead_field'),
            document.getElementById('team_lead_field'),
            document.getElementById('associate_team_lead_field')
        ];

        if (value === 'no') {
            fields.forEach(field => {
                field.style.visibility = 'hidden';
                field.style.height = '0';
                field.style.margin = '0';
                field.style.padding = '0';
            });
        } else if (value === 'yes') {
            fields.forEach(field => {
                field.style.visibility = 'visible';
                field.style.height = '';
                field.style.margin = '';
                field.style.padding = '';
            });
        }
    });
</script>


                <br><br>
            <div>
                <span class="title">Recruiter Details</span>
                    <div class="fields">
<!-- 
                        <div class="input-field">
                            <label>Business unit</label>
                            <input type="text"   name="business_unit" >
                        </div> -->


                        <div class="input-field">
                            <label>Business Unit</label>
                            <select name="business_unit" >
                                <option disabled selected>Select option</option>
                                <option>Sidd</option>
                                <option>Oliver</option>
                                <option>Nambu</option>
                                <option>Rohit</option>
                                <option>Vinay</option>
                            </select>
                        </div>

                        <!-- <div class="input-field">
                            <label>Client account lead / Client partner</label>
                            <input type="text"   name="client_account_lead" >
                        </div> -->

                        <div class="input-field">
                            <label>Client Account Lead / Client Partner</label>
                            <select name="client_account_lead" >
                                <option disabled selected>Select option</option>
                                <option>Amit</option>
                                <option>Abhishek</option>
                                <option>Aditya</option>
                                <option>Abhishek / Aditya</option>
                                <option>Vijay Methani</option>
                                <option>David</option>
                                <option>Devna</option>
                                <option>Don</option>
                                <option>Monse</option>
                                <option>Nambu</option>
                                <option>Narayan</option>
                                <option>Parijat</option>
                                <option>Priscilla</option>
                                <option>Sudip</option>
                                <option>Vinay</option>
                                <option>Prasanth Ravi</option>
                                <option>Sachin Sinha</option>
                                <option>Susan Johnson</option>
                                <option>NA</option>
                            </select>
                        </div>

                        <!-- <div class="input-field">
                            <label>Associate Director Delivery</label>
                            <input type="text"   name="associate_director_delivery" >
                        </div> -->

                        <div class="input-field">
                            <label>Associate Director Delivery</label>
                            <select name="associate_director_delivery" >
                                <option disabled selected>Select option</option>
                                <option>Mohanavelu Alavandhar - 12186</option>
                                <option>Ajay D - 10009</option>
                                <option>Soloman S - 10006</option>
                                <option>Manoj B G - 10058</option>
                            </select>
                        </div>
<!--                 
                        <div class="input-field">
                            <label>Delivery Manager</label>
                            <input type="text"   name="delivery_manager1" >
                        </div> -->

                        <div class="input-field">
                            <label>Delivery Manager</label>
                            <select name="delivery_manager1" >
                                <option disabled selected>Select option</option>
                                <option>Arun Franklin Joseph - 10344</option>
                                <option>Dinesh D - 10137</option>
                                <option>Dino Zeoff M - 10097</option>
                                <option>Karthikesan J - 10082</option>
                                <option>Michael Devaraj A - 10123</option>
                                <option>Mohammed Liazar L - 10066</option>
                                <option>Omar Mohamed - 10944</option>
                                <option>Richa Verma - 10606</option>
                                <option>Seliyan M - 10028</option>
                                <option>Srivijayaraghavan M - 10270</option>
                                <option>Vandhana R R - 10021</option>

                            </select>
                        </div>

                        <!-- <div class="input-field">
                            <label>Delivery Account Lead</label>
                            <input type="text"   name="delivery_account_lead1" >
                        </div> -->


                        <div class="input-field">
                            <label>Delivery Account Lead</label>
                            <select name="delivery_account_lead1" >
                                <option disabled selected>Select option</option>
                                <option>Celestine S - 10269</option>
                                <option>Iyngaran C - 12706</option>
                                <option>Prassannakumar Vijayakumar - 11738</option>
                                <option>Praveenkumar Kandasamy - 12422</option>
                                <option>Sinimary X - 10365</option>
                                <option>Vivek B - 10094</option>
                            </select>
                        </div>
<!-- 
                        <div class="input-field">
                            <label>Team Lead</label>
                            <input type="text"   name="team_lead1" >
                        </div> -->


                        <div class="input-field">
                            <label>Team Lead</label>
                            <select name="team_lead1" >
                                <option disabled selected>Select option</option>
                                <option>Balaji K - 11082</option>
                                <option>C Priya - 11648</option>
                                <option>Deepak Ganesan - 12702</option>
                                <option>Dinakaran G - 11426</option>
                                <option>Guna Sekaran S - 10488</option>
                                <option>Guru Samy N - 10924</option>
                                <option>Ibrahim Khan S - 10444</option>
                                <option>Jerammica Lydia J - 11203</option>
                                <option>Kumuthavalli Periyannan - 10681</option>
                                <option>M Balaji - 10509</option>
                                <option>Maheshwari M - 10627</option>
                                <option>Manikandan Shanmugam - 12409</option>
                                <option>Mathew P - 10714</option>
                                <option>Mohamed Al Fahd M - 11062</option>
                                <option>Mohamed Azharuddin T - 10912</option>
                                <option>Murugeswari K - 10360</option>
                                <option>Prasanna - 11925</option>
                                <option>Prathap T - 10672</option>
                                <option>Rajkeran A - 10518</option>
                                <option>Ramesh Murugan - 10766</option>
                                <option>Revathi B - 10799</option>
                                <option>Santhoshkumar S - 10443</option>
                                <option>Saral - 10201</option>
                                <option>Sastha Karthick M - 10662</option>
                                <option>Selvakumar J - 10727</option>
                                <option>Siraj Basha M - 10711</option>
                                <option>Suriya Senthilnathan - 10643</option>
                                <option>Veerabathiran B - 10717</option>
                                <option>Vijay Karthick M - 11075</option>
                            </select>
                        </div>

                        <div class="input-field">
                            <label>Associate Team Lead</label>
                            <input type="text"   name="associate_team_lead1" >
                        </div>

                        <!-- <div class="input-field">
                            <label>Recruiter Name (As per HR record)</label>
                            <input type="text"   name="recruiter_name" >
                        </div> -->


                        <div class="input-field">
                            <label>Recruiter Name (As per HR record)</label>
                            <select name="recruiter_name" >
                                <option disabled selected>Select option</option>
                                <option>Aarthy - 11862</option>
                                <option>Aasath Khan - 12377</option>
                                <option>Abarna Selva Kumar - 11538</option>
                                <option>Abdul Rahman Mohamed Aathil R - 12469</option>
                                <option>Abinaya Ramesh - 12379</option>
                                <option>Abirami Ramdoss - 11276</option>
                                <option>Agnes Agalya Aron - 12381</option>
                                <option>Akash P - 12670</option>
                                <option>Allwin Charles Dane Jacobmaran - 12057</option>
                                <option>Amisha Sulthana J - 12671</option>
                                <option>Angelin Simi John - 11542</option>
                                <option>Anitha Kumar - 12234</option>
                                <option>Arumairaja - 11974</option>
                                <option>Arun Balan - 12254</option>
                                <option>Arun Franklin Joseph - 10344</option>
                                <option>Arunachalam. C M - 12556</option>
                                <option>Arunkumar Ayyappan - 12627</option>
                                <option>Arunkumar Ganesan - 12645</option>
                                <option>Balaguru V - 12382</option>
                                <option>Balaji K - 11082</option>
                                <option>Balaji R - 11333</option>
                                <option>Balakrishnan V - 11540</option>
                                <option>Bharani Dharan R - 11799</option>
                                <option>Bhuvaneswaran Raj - 12136</option>
                                <option>C Priya - 11648</option>
                                <option>Celestine S - 10269</option>
                                <option>Deepak Ganesan - 12702</option>
                                <option>Deepika Rose K - 11756</option>
                                <option>Dharani K - 11605</option>
                                <option>Dhashanee Shanmugam - 11962</option>
                                <option>Dinakaran G - 11426</option>
                                <option>Dinesh D - 10137</option>
                                <option>Dinesh Kannan   - 11922</option>
                                <option>Dino Zeoff M - 10097</option>
                                <option>Divya Chitrasu - 12343</option>
                                <option>Elankumaran V - 11110</option>
                                <option>Elavenil - 11846</option>
                                <option>G Abrar Shariff - 12235</option>
                                <option>Gaya Priya N - 12067</option>
                                <option>Giftsondaniel S - 12245</option>
                                <option>Gladiya Jenies Santhanaraj - 12236</option>
                                <option>Guna Sekaran S - 10488</option>
                                <option>Guru Samy N - 10924</option>
                                <option>Ibrahim Afreedeen S - 12531</option>
                                <option>Ibrahim Khan S - 10444</option>
                                <option>Imran Tharik S - 12679</option>
                                <option>Infantjohnpraveen Anbalagan - 12630</option>
                                <option>Iyngaran C - 12706</option>
                                <option>Jeeva Krishnan - 12485</option>
                                <option>Jenifer M - 11758</option>
                                <option>Jerammica Lydia J - 11203</option>
                                <option>Jerin Renold J - 12237</option>
                                <option>Jesima Begum - 12675</option>
                                <option>Justeen D - 11254</option>
                                <option>Justinsamuvel M - 12486</option>
                                <option>K M Mohamed Ali - 11588</option>
                                <option>K Rakkesh Kumar - 12297</option>
                                <option>K.Elango - 12368</option>
                                <option>Kanakavalli M - 11997</option>
                                <option>Kanishkar Poonachi - 11393</option>
                                <option>Karishma M - 12472</option>
                                <option>Karkuzhali R - 11802</option>
                                <option>Karthiga Kathiresan - 12206</option>
                                <option>Karthikesan J - 10082</option>
                                <option>Kathiravan K - 11966</option>
                                <option>Kiran Azad Ram Prasad Azad - 12514</option>
                                <option>Kirthika Muruganantham - 12616</option>
                                <option>Kirupakaran P - 12615</option>
                                <option>Kishore Bharathy K P - 12348</option>
                                <option>Kumuthavalli Periyannan - 10681</option>
                                <option>Laxma Nandhini Suresh - 12386</option>
                                <option>Lingaprasanth Srinivasan - 11370</option>
                                <option>M Balaji - 10509</option>
                                <option>Mahadeenmohamed jaheerhussain - 12238</option>
                                <option>Maheshwari M - 10627</option>
                                <option>Manikandan S - 11967</option>
                                <option>Manikandan Shanmugam - 12409</option>
                                <option>Manojkumar - 12200</option>
                                <option>Manojkumar B - 10780</option>
                                <option>Martina Arockia Samy - 12552</option>
                                <option>Mathew P - 10714</option>
                                <option>Michael Devaraj A - 10123</option>
                                <option>Mithran Jayaseelan - 12683</option>
                                <option>Mohamed Al Fahd M - 11062</option>
                                <option>Mohamed Azharuddin T - 10912</option>
                                <option>Mohamed Idhirish M - 12625</option>
                                <option>Mohamed Nawaz Sheik Abdullah - 11727</option>
                                <option>Mohamed Rafi - 11523</option>
                                <option>Mohamed Razith - 11109</option>
                                <option>Mohamed Yasin S - 11980</option>
                                <option>Mohammed Liazar L - 10066</option>
                                <option>Mohanraj Ramar - 12162</option>
                                <option>Moorthy Muruganatham - 12682</option>
                                <option>Mukesh R - 12352</option>
                                <option>Mukundhan A - 12676</option>
                                <option>Murugeswari K - 10360</option>
                                <option>Myvizhi Sekar - 11478</option>
                                <option>Narayanan Ganesan - 12553</option>
                                <option>Narean Karthick B - 12620</option>
                                <option>Naveen Senthilkumar - 11281</option>
                                <option>Nesan M - 10673</option>
                                <option>Niruban Chandrasekaran - 12609</option>
                                <option>Omar Mohamed - 10944</option>
                                <option>Parthipan Nadesan  - 11885</option>
                                <option>Pavan Kumar  - 11921</option>
                                <option>Pavish Balakrishnan - 12563</option>
                                <option>Prabakaran Velupillai - 12256</option>
                                <option>Prakash Raj Chandrasekar - 12333</option>
                                <option>Prasanna - 11925</option>
                                <option>Prassannakumar Vijayakumar - 11738</option>
                                <option>Prathap T - 10672</option>
                                <option>Praveenkumar Kandasamy - 12422</option>
                                <option>Praveenraj Sivakumar - 12390</option>
                                <option>Premkumar. D - 70048</option>
                                <option>R M S Midunsathyaa - 12518</option>
                                <option>Radhika R - 10815</option>
                                <option>Raj Kishore Harindranath - 11531</option>
                                <option>Rajarajeshwari V - 12391</option>
                                <option>Rajkeran A - 10518</option>
                                <option>Rakshana B - 12542</option>
                                <option>Ramanakrishanan Ganesan - 12677</option>
                                <option>Ramesh Kumar Dharanya R - 12003</option>
                                <option>Ramesh Murugan - 10766</option>
                                <option>Revathi B - 10799</option>
                                <option>Richa Verma - 10606</option>
                                <option>Sahana Rajamansingh - 12562</option>
                                <option>Sam Fedrick - 11929</option>
                                <option>Sanjai Ramesh - 12626</option>
                                <option>Santhosh M - 12075</option>
                                <option>Santhoshkumar S - 10443</option>
                                <option>Saral - 10201</option>
                                <option>Saravana Maheswaran - 11774</option>
                                <option>Saravanan Rajendran - 12462</option>
                                <option>Sastha Karthick M - 10662</option>
                                <option>Sattanathan Bahadur - 11709</option>
                                <option>Seliyan M - 10028</option>
                                <option>Selvakumar J - 10727</option>
                                <option>Selvakumar M - 12201</option>
                                <option>Shabaresh Muthusamy - 12168</option>
                                <option>Shanmuganandha Krishnan - 11969</option>
                                <option>Sharli Sangeetha J - 12628</option>
                                <option>Sharmila Banu - 11903</option>
                                <option>Sheema H - 11042</option>
                                <option>Silpha Roselin A  - 11833</option>
                                <option>Sinimary X - 10365</option>
                                <option>Siraj Basha M - 10711</option>
                                <option>Sivabalan D - 12122</option>
                                <option>Sivakkumarvallalar - 11372</option>
                                <option>Sivakumar Senthilnathan - 12007</option>
                                <option>Sivasangari Venkatasubramanian - 12479</option>
                                <option>Sivasankar C  - 11830</option>
                                <option>Sri Ranjani Murugesan - 12174</option>
                                <option>Srivijayaraghavan M - 10270</option>
                                <option>Stephen Pradeep Mohan - 12463</option>
                                <option>Subash Antony  - 12703</option>
                                <option>Suganth T - 11940</option>
                                <option>Sumeet Tamilvanan - 12550</option>
                                <option>Suriya Senthilnathan - 10643</option>
                                <option>Surya Sekar - 11224</option>
                                <option>Swetha M - 12681</option>
                                <option>Syed kappar Aasif - 11396</option>
                                <option>Thangasehar V - 12673</option>
                                <option>Umera Ismail Khan - 11389</option>
                                <option>Vandhana R R - 10021</option>
                                <option>Veerabathiran B - 10717</option>
                                <option>Venkatesan Sudharsanam - 11631</option>
                                <option>Vignesh Moorthy Rajalingam - 12680</option>
                                <option>Vignesh P - 12402</option>
                                <option>Vigneshwaran R - 12480</option>
                                <option>Vigneshwaran Rajendran - 12481</option>
                                <option>Vigraman A - 12566</option>
                                <option>Vijay C - 11120</option>
                                <option>Vijay Karthick M - 11075</option>
                                <option>Vijayakannan S - 12568</option>
                                <option>Vinothini Moorthy - 11373</option>
                                <option>Vishal Agassivarma - 12171</option>
                                <option>Vivek B - 10094</option>
                                <option>Vivek Kumar Panneerselvam - 12202</option>

                            </select>
                        </div>


                        <div class="input-field">
                            <label>Recruiter Employee ID</label>
                            <input type="text"   name="recruiter_employee_id" >
                        </div>

                        <div class="input-field">
                            <label>PT Support</label>
                            <input type="text"   name="pt_support" >
                        </div>

                        <div class="input-field">
                            <label>PT Ownership</label>
                            <input type="text"   name="pt_ownership" >
                        </div>

                        <div class="input-field">
                            <label>COE/NON-COE</label>
                            <select name="coe_non_coe" >
                                <option disabled selected>Select option</option>
                                <option>COE</option>
                                <option>NON-COE</option>
                            </select>
                        </div>

                    </div>         
                </div>


            <br><br>
            <div>
                <span class="title">Project Details</span>
                    <div class="fields">

                        <!-- <div class="input-field">
                            <label>GEO</label>
                            <input type="text"   name="geo" >
                        </div> -->

                        <div class="input-field">
                            <label>GEO</label>
                            <select name="geo" >
                                <option disabled selected>Select option</option>
                                <option>USA</option>
                                <option>MEX</option>
                                <!-- <option>Aditya</option> -->
                                <option>CAN</option>
                                <option>CR</option>
                                <option>AUS</option>
                                <option>JAP</option>
                                <option>Spain</option>
                                <option>UAE</option>
                                <option>UK</option>
                                <option>PR</option>
                                <option>Brazil</option>
                                <!-- <option>Priscilla</option> -->
                                <option>Belgium</option>
                                <option>IND</option>
                            </select>
                        </div>

                        <div class="input-field">
                            <label>Entity</label>
                            <input type="text"   name="entity" >
                        </div>

                        <div class="input-field">
                            <label>Client</label>
                            <input type="text"   name="client" >
                        </div>
                
                        <div class="input-field">
                            <label>Client Manager</label>
                            <input type="text"   name="client_manager" >
                        </div>

                        <div class="input-field">
                            <label>Client Manager Email ID</label>
                            <input type="email"  name="client_manager_email_id" >
                        </div>

                        <div class="input-field">
                            <label>End Client</label>
                            <input type="text"   name="end_client" >
                        </div>

                        <div class="input-field">
                            <label>Business Track</label>
                            <input type="text"   name="business_track" >
                        </div>

                        <div class="input-field">
                            <label>Industry</label>
                            <input type="text"   name="industry" >
                        </div>

                        <div class="input-field">
                            <label>Experience in Expertise Role | Hands on</label>
                            <input type="text"   name="experience_in_expertise_role" >
                        </div>

                        <div class="input-field">
                            <label>Job Code</label>
                            <input type="text"   name="job_code" >
                        </div>

                        <div class="input-field">
                            <label>Job Title / Role</label>
                            <input type="text"   name="job_title" >
                        </div>

                        <div class="input-field">
                            <label>Primary Skill (Candidate)</label>
                            <input type="text"   name="primary_skill" >
                        </div>

                        <div class="input-field">
                            <label>Secondary Skill (Candidate)</label>
                            <input type="text"   name="secondary_skill" >
                        </div>

                        <div class="input-field">
                            <label>Term</label>
                            <select name="term" >
                                <option disabled selected>Select option</option>
                                <option>CON</option>
                                <option>C2H</option>
                                <option>FTE</option>
                                <option>1099</option>
                            </select>
                        </div>

                        <div class="input-field">
                            <label>Duration</label>
                            <input type="text"   name="duration" >
                        </div>

                        <div class="input-field">
                            <label>Project Location</label>
                            <input type="text"   name="project_location" >
                        </div>

                        <div class="input-field">
                            <label>Start Date</label>
                            <input type="date"  name="start_date" >
                        </div>

                        <div class="input-field">
                            <label>End Date</label>
                            <input type="date"  name="end_date" >
                        </div>

                        <div class="input-field">
                            <label>Payrate/Salary</label>
                            <input type="text"   name="payrate" >
                        </div>

                        <div class="input-field">
                            <label>Clientrate/Salary</label>
                            <input type="text"   name="clientrate" >
                        </div>

                        <div class="input-field">
                            <label>Margin</label>
                            <input type="text"   name="margin" >
                        </div>

                        <div class="input-field">
                            <label>Vendor Fee (If Applicable)</label>
                            <input type="text"   name="vendor_fee" >
                        </div>

                        <div class="input-field">
                            <label>Margin Deviation Approval (Yes/No)</label>
                            <select name="margin_deviation_approval" >
                                <option disabled selected>Select option</option>
                                <option>Yes</option>
                                <option>No</option>
                            </select>
                        </div>

                        <div class="input-field">
                            <label>Margin Deviation Reason</label>
                            <input type="text"   name="margin_deviation_reason" >
                        </div>

                        <div class="input-field">
                            <label>Ratecard Adherence (Yes/No)</label>
                            <select name="ratecard_adherence" >
                                <option disabled selected>Select option</option>
                                <option>Yes</option>
                                <option>No</option>
                            </select>
                        </div>

                        <div class="input-field">
                            <label>Ratecard Deviation Reason</label>
                            <input type="text"   name="ratecard_deviation_reason" >
                        </div>

                        <div class="input-field">
                            <label>Ratecard Deviation Approved (Yes/No)</label>
                            <select name="ratecard_deviation_approved" >
                                <option disabled selected>Select option</option>
                                <option>Yes</option>
                                <option>No</option>
                            </select>
                        </div>

                        <div class="input-field">
                            <label>Payment Term</label>
                            <input type="text"   name="payment_term" >
                        </div>

                        <div class="input-field">
                            <label>Payment Term Approval (Yes/No)</label>
                            <select name="payment_term_approval" >
                                <option disabled selected>Select option</option>
                                <option>Yes</option>
                                <option>No</option>
                            </select>
                        </div>

                        <div class="input-field">
                            <label>Payment Term Deviation Reason</label>
                            <input type="text"   name="payment_term_deviation_reason" >
                        </div>

                        <div class="input-field">
                            <label>Type</label>
                            <select name="type" >
                                <option disabled selected>Select option</option>
                                <option>Deal</option>
                                <option>PT</option>
                                <option>PTR</option>
                                <option>VC</option>
                            </select>
                        </div>

                    </div>         
                </div>

                <!-- File upload fields -->
        <!-- <label for="resume">Resume:</label>
        <input type="file" id="resume" name="resume" required>
        <br>
        <label for="photo_id">Photo ID:</label>
        <input type="file" id="photo_id" name="photo_id" >
        
        <label for="wa_document">Work Authorization:</label>
        <input type="file" id="wa_document" name="wa_document" >-->

                <div class="input-field">
                    <button type="submit">Submit</button>
                </div> 

            </div>   
        </div>
    </form>
</div>

<script src="script.js"></script>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script type="text/javascript">
    document.getElementById('myForm').addEventListener('submit', function(event) {
        event.preventDefault(); // Prevent the form from submitting immediately

        Swal.fire({
            title: 'Are you sure?',
            text: "Do you want to submit the form?",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, submit it!'
        }).then((result) => {
            if (result.isConfirmed) {
                // Show loading spinner
                Swal.fire({
                    title: 'Submitting...',
                    text: 'Please wait while we process your request.',
                    didOpen: () => {
                        Swal.showLoading(); // Show the loading spinner
                    },
                    allowOutsideClick: false,
                    allowEscapeKey: false
                });

                // Use FormData to handle the form data
                const form = event.target;
                const formData = new FormData(form);

                fetch(form.action, {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.text())
                .then(data => {
                    // Hide the loading spinner and show success message
                    Swal.fire({
                        title: 'Submitted!',
                        text: 'The paperwork has been submitted successfully.',
                        icon: 'success'
                    }).then(() => {
                        // Optionally redirect or reset the form
                        form.reset(); // Reset the form if needed
                        // window.location.href = 'somepage.php'; // Redirect if needed
                    });
                })
                .catch(error => {
                    // Hide the loading spinner and show error message
                    Swal.fire({
                        title: 'Error!',
                        text: 'An error occurred while submitting the form.',
                        icon: 'error'
                    });
                });
            }
        });
    });
</script>

<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

    <!-- <script>
        $(document).ready(function() {
            $('select[name="recruiter_name"]').select2({
                placeholder: "Select option",
                allowClear: true
            });
        });
    </script> -->
</body>
</html>